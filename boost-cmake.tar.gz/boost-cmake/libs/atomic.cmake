_add_boost_lib(
  NAME atomic
  SOURCES
    ${BOOST_SOURCE}/libs/atomic/src/lock_pool.cpp
  DEFINE_PRIVATE
    BOOST_ATOMIC_STATIC_LINK=1
    BOOST_ATOMIC_SOURCE
)

include(CheckCXXSourceCompiles)

if (CMAKE_CXX_COMPILER_ID STREQUAL "MSVC")
    if (CMAKE_SIZEOF_VOID_P EQUAL 4)
        set(boost_atomic_sse2_cflags "/arch:SSE2")
        set(boost_atomic_sse41_cflags "/arch:SSE2")
    endif()
elseif (CMAKE_CXX_COMPILER_ID STREQUAL "Intel")
    if (WIN32)
        set(boost_atomic_sse2_cflags "/QxSSE2")
        set(boost_atomic_sse41_cflags "/QxSSE4.1")
    else()
        set(boost_atomic_sse2_cflags "-xSSE2")
        set(boost_atomic_sse41_cflags "-xSSE4.1")
    endif()
else()
    set(boost_atomic_sse2_cflags "-msse -msse2")
    set(boost_atomic_sse41_cflags "-msse -msse2 -msse3 -mssse3 -msse4.1")
endif()

set(CMAKE_REQUIRED_INCLUDES "${CMAKE_CURRENT_SOURCE_DIR}/../..")
set(CMAKE_REQUIRED_FLAGS "${boost_atomic_sse2_cflags}")
check_cxx_source_compiles("#include <${CMAKE_CURRENT_SOURCE_DIR}/config/has_sse2.cpp>" BOOST_ATOMIC_COMPILER_HAS_SSE2)
unset(CMAKE_REQUIRED_FLAGS)
unset(CMAKE_REQUIRED_INCLUDES)

set(CMAKE_REQUIRED_INCLUDES "${CMAKE_CURRENT_SOURCE_DIR}/../..")
set(CMAKE_REQUIRED_FLAGS "${boost_atomic_sse41_cflags}")
check_cxx_source_compiles("#include <${CMAKE_CURRENT_SOURCE_DIR}/config/has_sse41.cpp>" BOOST_ATOMIC_COMPILER_HAS_SSE41)
unset(CMAKE_REQUIRED_FLAGS)
unset(CMAKE_REQUIRED_INCLUDES)

if (BOOST_ATOMIC_COMPILER_HAS_SSE2)
    set(boost_atomic_sources_sse2 src/find_address_sse2.cpp)
    set_source_files_properties(${boost_atomic_sources_sse2} PROPERTIES COMPILE_FLAGS "${boost_atomic_sse2_cflags}")
    set(boost_atomic_sources ${boost_atomic_sources} ${boost_atomic_sources_sse2})
endif()

if (BOOST_ATOMIC_COMPILER_HAS_SSE41)
    set(boost_atomic_sources_sse41 src/find_address_sse41.cpp)
    set_source_files_properties(${boost_atomic_sources_sse41} PROPERTIES COMPILE_FLAGS "${boost_atomic_sse41_cflags}")
    set(boost_atomic_sources ${boost_atomic_sources} ${boost_atomic_sources_sse41})
endif()

_add_boost_test(
  NAME atomic_test
  LINK
    Boost::atomic
    Boost::thread
  DEFINE
    # The tests expect APIs deprecated in Thread v4, so enable them
    BOOST_THREAD_PROVIDES_NESTED_LOCKS=1
    BOOST_THREAD_USES_DATETIME=1
  TESTS
    RUN ${BOOST_SOURCE}/libs/atomic/test/native_api.cpp
    RUN ${BOOST_SOURCE}/libs/atomic/test/fallback_api.cpp
    RUN ${BOOST_SOURCE}/libs/atomic/test/atomicity.cpp
    RUN ${BOOST_SOURCE}/libs/atomic/test/ordering.cpp
    RUN ${BOOST_SOURCE}/libs/atomic/test/lockfree.cpp
)
