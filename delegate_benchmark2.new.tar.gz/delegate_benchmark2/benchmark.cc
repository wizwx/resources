#pragma once
#include <iostream>
#include <chrono>
#include "fastdelegate/FastDelegate.h"
#include "cppdelegate/Delegate.h"
#include "cppdelegate/MultiCastDelegate.h"
#include "srutil/delegate/delegate.hpp"
#include "cppdelete2.h"
#include "cppdelegate.hh"
#include "inplace_function.h"

typedef uint64_t ns;
typedef uint32_t rep;

#ifdef SRUTIL_DELEGATE_PREFERRED_SYNTAX
typedef srutil::delegate<double (int)> TestDelegate;
#else
typedef srutil::delegate1<double, int> TestDelegate;
#endif

class Sample {
  long mB;
public:
  double A(int) { return 0.1; }
  static double B(int) { return 0.2; }
  virtual double C(int) { return 0.3; }
}; //class Sample

class SampleD : public Sample {
  long mD;
public:
  double C(int) { return 0.4; }
};

const int delegate_count = 10000;

class Benchmark {
		SA::delegate<double(int)> cppdelegates[delegate_count];
    TestDelegate srdelegates[delegate_count];
    fastdelegate::FastDelegate1<int, double> fastdelegates[delegate_count];
		std::function<double(int)> functions[delegate_count];
    XW::Delegate<double(int)> cppdelegates2[delegate_count];
    stdext::inplace_function<double(int)> inplacefunc[delegate_count];

		std::chrono::high_resolution_clock clock;
		std::chrono::high_resolution_clock::time_point before;
		void Start() { before = clock.now(); }
		ns Stop() {
			auto after = clock.now();
			auto duration = std::chrono::duration_cast<std::chrono::nanoseconds>(after - before).count();
			return duration;
		} //Stop

    Sample sample;
    SampleD derived;

public:

	void create() {
      // cppdelegates 
      Start();
      for (int i=0; i<delegate_count; ++i) {
        cppdelegates[i] = SA::delegate<double(int)>::create<Sample, &Sample::A>(&sample);
      }
      ns ns1 = Stop();
      std::cout << "cppdeletegate init = " << ns1 << std::endl;

      // cppdelegates2 
      Start();
      for (int i=0; i<delegate_count; ++i) {
        cppdelegates2[i] = XW::Delegate<double(int)>::create<Sample, &Sample::A>(&sample);
      }
      ns ns5 = Stop();
      std::cout << "cppdeletegate2 init = " << ns5 << std::endl;
      
      // inplace_function 
      Start();
      for (int i=0; i<delegate_count; ++i) {
        inplacefunc[i] = std::bind(&Sample::A, &sample, std::placeholders::_1);
      }
      ns ns6 = Stop();
      std::cout << "inplace_function init = " << ns6 << std::endl;
      
      // sr delegate
      Start();
      for (int i=0; i<delegate_count; ++i) {
        srdelegates[i] = TestDelegate::from_method<Sample, &Sample::A>(&sample);
      }
      ns ns2 = Stop();
      std::cout << "srdeletegate init = " << ns2 << std::endl;

      // fast delegate
      Start();
      for (int i=0; i<delegate_count; ++i) {
        fastdelegates[i] = fastdelegate::MakeDelegate(&sample, &Sample::A);
      }
      ns ns3 = Stop();
      std::cout << "fastdeletegate init = " << ns3 << std::endl;

      // function
      Start();
      for (int i=0; i<delegate_count; ++i) {
        functions[i] = std::bind(&Sample::A, &sample, std::placeholders::_1);
      }
      ns ns4 = Stop();
      std::cout << "std::function init = " << ns4 << std::endl;
      
	} //create

	void invoke() {
      // cppdelegates 
      Start();
      for (int i=0; i<delegate_count; ++i) {
        cppdelegates[i](1);
      }
      ns ns1 = Stop();
      std::cout << "cppdeletegate invoke = " << ns1 << std::endl;
      
      // cppdelegates2 
      Start();
      for (int i=0; i<delegate_count; ++i) {
        cppdelegates2[i](1);
      }
      ns ns5 = Stop();
      std::cout << "cppdeletegate2 invoke = " << ns1 << std::endl;
      
      // inplace_function 
      Start();
      for (int i=0; i<delegate_count; ++i) {
        inplacefunc[i](1);
      }
      ns ns6 = Stop();
      std::cout << "inplace_function init = " << ns6 << std::endl;
      
      // sr delegate
      Start();
      for (int i=0; i<delegate_count; ++i) {
        srdelegates[i](1);
      }
      ns ns2 = Stop();
      std::cout << "srdeletegate invoke = " << ns2 << std::endl;

      // fast delegate
      Start();
      for (int i=0; i<delegate_count; ++i) {
        fastdelegates[i](1);
      }
      ns ns3 = Stop();
      std::cout << "fastdeletegate invoke = " << ns3 << std::endl;

      // function
      Start();
      for (int i=0; i<delegate_count; ++i) {
        functions[i](1);
      }
      ns ns4 = Stop();
      std::cout << "std::function invoke = " << ns4 << std::endl;
      
	} //create

  /*
private:

	template<size_t delegate_count, rep creation_repeat_count, rep call_count, typename DELEGATE, typename RET, typename... PARAMS>
	class OperationSet {
	private:
		ns DelegateCreation() {
			Sample sample;
			Start();
			for (rep repeat_index = 0; repeat_index < creation_repeat_count; ++repeat_index)
				for (DELEGATE *j = delegates; j != delegates + delegate_count; ++j)
					*j = DELEGATE:: template create<Sample, &Sample::A>(&sample);
			return Stop();
		}; //DelegateCreation
		ns LambdaDelegateCreation()  {
			auto lambda = [](PARAMS...) -> RET { return 0.0; };
			Start();
			for (rep repeat_index = 0; repeat_index < creation_repeat_count; ++repeat_index)
				for (DELEGATE *j = delegates; j != delegates + delegate_count; ++j)
					*j = SA::delegate<RET(PARAMS...)>:: template create<decltype(lambda)>(lambda);
			return Stop();
		} //LambdaDelegateCreation
		ns DelegateCall(PARAMS... arg) {
			Start();
			for (size_t delegate = 0; delegate < delegate_count; ++delegate)
				for (size_t index = 0; index < call_count; ++index)
					delegates[delegate](arg...);
			return Stop();
		} //DelegateCall
		ns FunctionCreation() {
			Sample sample;
			using namespace std::placeholders;
			Start();
			for (rep repeat_index = 0; repeat_index < creation_repeat_count; ++repeat_index)
				for (std::function<RET(PARAMS...)> *j = functions; j != functions + delegate_count; ++j)
					*j = std::bind(&Sample::A, &sample, _1);
			return Stop();
		} //FunctionCreation
		ns LambdaFunctionCreation() {
			auto lambda = [](PARAMS...) -> RET { return 0.0; };
			Start();
			for (unsigned int repeat_index = 0; repeat_index < creation_repeat_count; ++repeat_index)
				for (std::function<RET(PARAMS...)> *j = functions; j != functions + delegate_count; ++j)
					*j = std::function<RET(PARAMS...)>(lambda);
			return Stop();
		}; //LambdaFunctionCreation
		ns FunctionCall(PARAMS... arg) {
			Start();
			for (size_t fun = 0; fun < delegate_count; ++fun)
				for (size_t index = 0; index < call_count; ++index)
					functions[fun](arg...);
			return Stop();
		}; //FunctionCall

	public:
		void Run(PARAMS... arg) {
			functionCreationTime = FunctionCreation();
			functionCallTime = FunctionCall(arg...);
			delegateCreationTime = DelegateCreation();
			delegateCallTime = DelegateCall(arg...);
			// lambda:
			lambdaFunctionCreationTime = LambdaFunctionCreation();
			lambdaFunctionCallTime = FunctionCall(arg...);
			lambdaDelegateCreationTime = LambdaDelegateCreation();
			lambdaDelegateCallTime = DelegateCall(arg...);
			Show();
		} //Run
	private:
		DELEGATE delegates[delegate_count];
		std::function<RET(PARAMS...)> functions[delegate_count];
		ns	delegateCreationTime,	lambdaDelegateCreationTime,	delegateCallTime,	lambdaDelegateCallTime,
			functionCreationTime,	lambdaFunctionCreationTime,	functionCallTime,	lambdaFunctionCallTime;
		void Show() {
			auto comparison = [&](ns creationTime1, ns callTime1, ns creationTime2, ns callTime2, const char* title) -> void {
				ns total1 = creationTime1 + callTime1;
				ns total2 = creationTime2 + callTime2;
				long double averageCreation1 = 1.0 * creationTime1 / (delegate_count * creation_repeat_count);
				long double averageCreation2 = 1.0 * creationTime2 / (delegate_count * creation_repeat_count);
				long double averageCall1 = 1.0 * callTime1 / (delegate_count * call_count);
				long double averageCall2 = 1.0 * callTime2 / (delegate_count * call_count);
				std::cout << title << ":" << std::endl;
				std::cout << "\tcreation: " << creationTime1 << " vs. " << creationTime2 << std::endl;
				std::cout << "\taverage creation: " << averageCreation1 << " vs. " << averageCreation2 << std::endl;
				std::cout << "\tcall: " << callTime1 << " vs. " << callTime2 << std::endl;
				std::cout << "\taverage call: " << averageCall1 << " vs. " << averageCall2 << std::endl;
				std::cout << "\ttotal: " << total1 << " vs. " << total2 << std::endl;
				std::cout << "\tcreation gain:\t" << 1.0*creationTime2/creationTime1 << std::endl;
				std::cout << "\tcall gain:\t" << 1.0*callTime2/ callTime1 << std::endl;
				std::cout << "\ttotal gain:\t" << 1.0*total2/total1 << std::endl;
			};
			comparison(delegateCreationTime, delegateCallTime, functionCreationTime, functionCallTime,
				"Instance methods of a class, delegate vs. std::function");
			comparison(lambdaDelegateCreationTime, lambdaDelegateCallTime, lambdaFunctionCreationTime, lambdaFunctionCallTime,
				"Lambda functions, delegate vs. std::function");
		} //Show
	}; //OperationSet
  */


}; /* class Benchmark */

int main() {
  Benchmark bench;
  bench.create();
  bench.invoke();
}
