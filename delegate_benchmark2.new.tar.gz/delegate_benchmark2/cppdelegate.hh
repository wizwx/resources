#ifndef __CPP_DELEGATE__
#define __CPP_DELEGATE__

namespace XW {

template <typename T> class Delegate;

template<typename RET, typename ...PARAMS>
class Delegate<RET(PARAMS...)> final {
public:
  Delegate() = default;

  Delegate(const Delegate& rhs) : obj_(rhs.obj_), stub_(rhs.stub_) {}

  Delegate& operator=(const Delegate& rhs) {
    assign(rhs.obj_, rhs.stub_);
    return *this;
  } //operator =

  template <typename LAMBDA>
  Delegate(const LAMBDA& lambda) {
    assign((void*)(&lambda), lambda_stub<LAMBDA>);
  } //delegate

  Delegate(RET(*TMethod)(PARAMS...)) {
    assign(nullptr, function_stub<TMethod>);
  } //delegate

  template <class T, RET(T::*TMethod)(PARAMS...)>
  static Delegate create(T* instance) {
    return Delegate(instance, method_stub<T, TMethod>);
  } //create

  template <class T, RET(T::*TMethod)(PARAMS...) const>
  static Delegate create(T const* instance) {
    return Delegate(const_cast<T*>(instance), const_method_stub<T, TMethod>);
  } //create

  template <RET(*TMethod)(PARAMS...)>
  static Delegate create() {
    return Delegate(nullptr, function_stub<TMethod>);
  } //create

  template <typename LAMBDA>
  static Delegate create(const LAMBDA & instance) {
    return Delegate((void*)(&instance), lambda_stub<LAMBDA>);
  } //create

  RET operator()(PARAMS &&... arg) const {
    return (*stub_)(obj_, std::forward<PARAMS>(arg)...);
  } //operator()

private:
  using stub_t = RET(*)(void* this_ptr, PARAMS&&...);
  void* obj_ = nullptr;
  stub_t stub_ = nullptr;

  Delegate(void* obj, stub_t stub) : obj_(obj), stub_(stub) {
  } //delegate

  void assign(void* obj, stub_t stub) {
    obj_ = obj;
    stub_ = stub;
  } //assign

  template <class T, RET(T::*TMethod)(PARAMS...)>
  static RET method_stub(void* obj, PARAMS &&... params) {
    T* p = static_cast<T*>(obj);
    return (p->*TMethod)(std::forward<PARAMS>(params)...);
  } //method_stub

  template <class T, RET(T::*TMethod)(PARAMS...) const>
  static RET const_method_stub(void* obj, PARAMS &&... params) {
    T* const p = static_cast<T*>(obj);
    return (p->*TMethod)(std::forward<PARAMS>(params)...);
  } //const_method_stub

  template <RET(*TMethod)(PARAMS...)>
  static RET function_stub(void* obj, PARAMS &&... params) {
    return (TMethod)(std::forward<PARAMS>(params)...);
  } //function_stub

  template <typename LAMBDA>
  static RET lambda_stub(void* obj, PARAMS &&... arg) {
    LAMBDA* p = static_cast<LAMBDA*>(obj);
    return (p->operator())(std::forward<PARAMS>(arg)...);
  } //lambda_stub
};

}

#endif // __CPP_DELEGATE__

