https://www.codeproject.com/Articles/18389/Fast-C-Delegate-Boost-Function-drop-in-replacement
https://www.codeproject.com/Articles/1170503/The-Impossibly-Fast-Cplusplus-Delegates-Fixed
https://www.codeproject.com/Articles/7150/Member-Function-Pointers-and-the-Fastest-Possible
https://www.codeproject.com/articles/11015/the-impossibly-fast-c-delegates
